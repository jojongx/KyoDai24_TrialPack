
def greeting():
    print("Hello KyoDai24 World!")
