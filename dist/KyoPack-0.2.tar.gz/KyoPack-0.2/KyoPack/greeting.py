
def greet():
    print("Hello KyoDai24 World!")


if __name__ == "__main__":
    greet()
